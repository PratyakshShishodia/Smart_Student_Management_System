/* ============================================================
   SMART SMS — script.js
   Full-featured Student Management System Logic
   ============================================================ */

// ============================================================
// STATE
// ============================================================
let students = [];
let attendanceData = {};  // { studentId: { date: 'present'|'absent', ... } }
let courseChart, attChart, marksChart, perfChart;
const TODAY = new Date().toISOString().split('T')[0];

// ============================================================
// STORAGE HELPERS
// ============================================================
function save() {
  localStorage.setItem('sms_students', JSON.stringify(students));
  localStorage.setItem('sms_attendance', JSON.stringify(attendanceData));
}

function load() {
  students = JSON.parse(localStorage.getItem('sms_students') || '[]');
  attendanceData = JSON.parse(localStorage.getItem('sms_attendance') || '{}');
}

// ============================================================
// LOGIN
// ============================================================
function doLogin() {
  const u = document.getElementById('loginUser').value.trim();
  const p = document.getElementById('loginPass').value.trim();
  if (u === 'admin' && p === 'admin123') {
    document.getElementById('loginPage').classList.add('hidden');
    document.getElementById('appShell').classList.remove('hidden');
    initApp();
  } else {
    document.getElementById('loginError').textContent = '✕ Invalid credentials. Try admin / admin123';
  }
}

document.addEventListener('keydown', e => {
  if (e.key === 'Enter' && !document.getElementById('loginPage').classList.contains('hidden')) {
    doLogin();
  }
});

function doLogout() {
  document.getElementById('appShell').classList.add('hidden');
  document.getElementById('loginPage').classList.remove('hidden');
  document.getElementById('loginUser').value = '';
  document.getElementById('loginPass').value = '';
}

// ============================================================
// INIT
// ============================================================
function initApp() {
  load();
  if (students.length === 0) seedDemoData();
  updateDate();
  renderDashboard();
  renderNotifications();
  setInterval(updateDate, 60000);
}

function updateDate() {
  const now = new Date();
  const opts = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' };
  const str = now.toLocaleDateString('en-IN', opts);
  document.getElementById('dateChip').textContent = str;
  document.getElementById('attendDateChip').textContent = str;
}

// ============================================================
// SEED DEMO DATA
// ============================================================
function seedDemoData() {
  const names = [
    ['Priya Sharma','priya.sharma@college.edu','B.Tech CSE','Semester 3','CS2024001','+91 9876543210','Delhi',88],
    ['Arjun Mehta','arjun.mehta@college.edu','B.Tech ECE','Semester 5','EC2024002','+91 9876543211','Mumbai',75],
    ['Ananya Singh','ananya.singh@college.edu','MCA','Semester 2','MC2024003','+91 9876543212','Bangalore',92],
    ['Rahul Verma','rahul.verma@college.edu','MBA','Semester 4','MB2024004','+91 9876543213','Pune',61],
    ['Neha Patel','neha.patel@college.edu','BCA','Semester 1','BC2024005','+91 9876543214','Ahmedabad',79],
    ['Kiran Rao','kiran.rao@college.edu','B.Tech CSE','Semester 7','CS2024006','+91 9876543215','Hyderabad',95],
    ['Suhail Khan','suhail.khan@college.edu','B.Tech ME','Semester 3','ME2024007','+91 9876543216','Lucknow',58],
    ['Divya Nair','divya.nair@college.edu','B.Sc Physics','Semester 5','BS2024008','+91 9876543217','Kochi',83],
  ];

  names.forEach((n, i) => {
    const id = 'std_' + Date.now() + '_' + i;
    students.push({
      id, name: n[0], email: n[1], course: n[2], semester: n[3],
      roll: n[4], phone: n[5], address: n[6], marks: n[7],
      photo: '', dob: '2002-0' + (i+1) + '-15',
      createdAt: new Date(Date.now() - i * 86400000).toISOString()
    });

    // Seed attendance: last 7 days
    attendanceData[id] = {};
    for (let d = 0; d < 7; d++) {
      const dd = new Date(Date.now() - d * 86400000).toISOString().split('T')[0];
      attendanceData[id][dd] = Math.random() > 0.2 ? 'present' : 'absent';
    }
  });
  save();
}

// ============================================================
// NAVIGATION
// ============================================================
function navigate(el) {
  const page = el.dataset.page;
  document.querySelectorAll('.nav-item').forEach(i => i.classList.remove('active'));
  el.classList.add('active');
  document.querySelectorAll('.page').forEach(p => p.classList.remove('active'));
  document.getElementById('page-' + page).classList.add('active');
  document.getElementById('topbarTitle').textContent = el.querySelector('span:last-child').textContent;

  // Close sidebar on mobile
  if (window.innerWidth < 700) toggleSidebar(false);

  // Page-specific renders
  if (page === 'dashboard') renderDashboard();
  if (page === 'records') renderTable(students);
  if (page === 'attendance') renderAttendance();
  if (page === 'analytics') renderAnalytics();
  if (page === 'idcard') renderIDCardSelect();
}

function toggleSidebar(forceClose) {
  const sb = document.getElementById('sidebar');
  if (forceClose === false) { sb.classList.remove('open'); return; }
  sb.classList.toggle('open');
}

// ============================================================
// THEME
// ============================================================
function toggleTheme() {
  const html = document.documentElement;
  const isDark = html.getAttribute('data-theme') === 'dark';
  html.setAttribute('data-theme', isDark ? 'light' : 'dark');
  document.getElementById('themeIcon').textContent = isDark ? '🌙' : '☀';
  document.getElementById('themeLabel').textContent = isDark ? 'Dark Mode' : 'Light Mode';
  // Re-render charts to respect theme
  if (document.getElementById('page-dashboard').classList.contains('active')) renderDashboard();
  if (document.getElementById('page-analytics').classList.contains('active')) renderAnalytics();
}

// ============================================================
// NOTIFICATIONS
// ============================================================
function renderNotifications() {
  const notifs = [
    { text: `<strong>${students.length} students</strong> enrolled this term` },
    { text: `Attendance updated for <strong>${TODAY}</strong>` },
    { text: `<strong>${students.filter(s=>s.marks >= 90).length} students</strong> scored 90+ marks` },
  ];
  const list = document.getElementById('notifList');
  list.innerHTML = notifs.map(n => `
    <div class="notif-item">
      <div class="notif-dot"></div>
      <div class="notif-text">${n.text}</div>
    </div>`).join('');
  document.getElementById('notifBadge').textContent = notifs.length;
}

function toggleNotif() {
  document.getElementById('notifPanel').classList.toggle('hidden');
}

document.addEventListener('click', e => {
  const panel = document.getElementById('notifPanel');
  if (!panel.contains(e.target) && !e.target.closest('.notif-btn')) {
    panel.classList.add('hidden');
  }
});

// ============================================================
// DASHBOARD
// ============================================================
function renderDashboard() {
  // Stats
  document.getElementById('statStudents').textContent = students.length;
  const courses = [...new Set(students.map(s => s.course))].filter(Boolean);
  document.getElementById('statCourses').textContent = courses.length;

  // Avg attendance
  let totalPct = 0, attCount = 0;
  students.forEach(s => {
    const pct = getAttendancePct(s.id);
    totalPct += pct; attCount++;
  });
  const avgAtt = attCount ? Math.round(totalPct / attCount) : 0;
  document.getElementById('statAttendance').textContent = avgAtt + '%';

  // Avg marks
  const withMarks = students.filter(s => s.marks !== undefined && s.marks !== '');
  const avgMarks = withMarks.length ? Math.round(withMarks.reduce((a,b) => a + Number(b.marks), 0) / withMarks.length) : 0;
  document.getElementById('statAvgGrade').textContent = avgMarks ? avgMarks + '/100' : '—';

  // Recent students
  const recent = [...students].sort((a,b) => new Date(b.createdAt) - new Date(a.createdAt)).slice(0,5);
  document.getElementById('recentStudentsList').innerHTML = recent.map(s => `
    <div class="recent-item">
      <div class="recent-avatar">
        ${s.photo ? `<img src="${s.photo}" />` : initials(s.name)}
      </div>
      <div>
        <div class="recent-name">${s.name}</div>
        <div class="recent-course">${s.roll}</div>
      </div>
      <span class="recent-tag">${s.course || '—'}</span>
    </div>`).join('') || '<p style="color:var(--text3);font-size:0.85rem;text-align:center;padding:20px">No students yet</p>';

  // Course distribution chart
  renderCourseChart(courses);

  // Attendance chart
  renderAttendanceOverviewChart();
}

function renderCourseChart(courseList) {
  if (courseChart) courseChart.destroy();
  const ctx = document.getElementById('courseChart').getContext('2d');
  const courseCounts = {};
  students.forEach(s => { if(s.course) courseCounts[s.course] = (courseCounts[s.course]||0) + 1; });
  const labels = Object.keys(courseCounts);
  const data = Object.values(courseCounts);

  courseChart = new Chart(ctx, {
    type: 'doughnut',
    data: {
      labels,
      datasets: [{ data, backgroundColor: ['#6ee7f7','#a78bfa','#34d399','#fb923c','#f87171','#fbbf24','#60a5fa','#f472b6'], borderWidth: 0 }]
    },
    options: {
      responsive: true, maintainAspectRatio: true,
      plugins: { legend: { position: 'bottom', labels: { color: getComputedStyle(document.documentElement).getPropertyValue('--text2').trim(), font: { family: 'DM Sans', size: 11 }, padding: 14 } } }
    }
  });
}

function renderAttendanceOverviewChart() {
  if (attChart) attChart.destroy();
  const ctx = document.getElementById('attendanceChart').getContext('2d');
  const days = [], presentCounts = [], absentCounts = [];
  for (let d = 6; d >= 0; d--) {
    const date = new Date(Date.now() - d * 86400000);
    const dateStr = date.toISOString().split('T')[0];
    const dayLabel = date.toLocaleDateString('en-IN', { weekday: 'short', day: 'numeric' });
    days.push(dayLabel);
    let present = 0, absent = 0;
    students.forEach(s => {
      const status = (attendanceData[s.id] || {})[dateStr];
      if (status === 'present') present++;
      else if (status === 'absent') absent++;
    });
    presentCounts.push(present);
    absentCounts.push(absent);
  }

  const textColor = getComputedStyle(document.documentElement).getPropertyValue('--text2').trim();
  const borderColor = getComputedStyle(document.documentElement).getPropertyValue('--border').trim();

  attChart = new Chart(ctx, {
    type: 'bar',
    data: {
      labels: days,
      datasets: [
        { label: 'Present', data: presentCounts, backgroundColor: 'rgba(52,211,153,0.7)', borderRadius: 6 },
        { label: 'Absent',  data: absentCounts,  backgroundColor: 'rgba(248,113,113,0.7)', borderRadius: 6 }
      ]
    },
    options: {
      responsive: true, maintainAspectRatio: true,
      scales: {
        x: { ticks: { color: textColor, font: { family: 'DM Sans', size: 11 } }, grid: { color: borderColor } },
        y: { ticks: { color: textColor, font: { family: 'DM Sans', size: 11 }, stepSize: 1 }, grid: { color: borderColor } }
      },
      plugins: { legend: { labels: { color: textColor, font: { family: 'DM Sans', size: 11 } } } }
    }
  });
}

// ============================================================
// ADD / EDIT STUDENT
// ============================================================
function previewPhoto(event) {
  const file = event.target.files[0];
  if (!file) return;
  const reader = new FileReader();
  reader.onload = e => {
    const preview = document.getElementById('photoPreview');
    preview.src = e.target.result;
    preview.classList.remove('hidden');
    document.getElementById('photoPlaceholder').classList.add('hidden');
  };
  reader.readAsDataURL(file);
}

function clearForm() {
  document.getElementById('fName').value = '';
  document.getElementById('fRoll').value = '';
  document.getElementById('fEmail').value = '';
  document.getElementById('fPhone').value = '';
  document.getElementById('fCourse').value = '';
  document.getElementById('fSem').value = '';
  document.getElementById('fAddress').value = '';
  document.getElementById('fMarks').value = '';
  document.getElementById('fDob').value = '';
  document.getElementById('editId').value = '';
  document.getElementById('photoPreview').classList.add('hidden');
  document.getElementById('photoPlaceholder').classList.remove('hidden');
  document.getElementById('formTitle').textContent = 'Add New Student';
  ['errName','errRoll','errEmail','errCourse'].forEach(id => document.getElementById(id).textContent = '');
}

function validateForm() {
  let valid = true;
  const name = document.getElementById('fName').value.trim();
  const roll = document.getElementById('fRoll').value.trim();
  const email = document.getElementById('fEmail').value.trim();
  const course = document.getElementById('fCourse').value;

  if (!name) { document.getElementById('errName').textContent = 'Name is required'; valid = false; }
  else document.getElementById('errName').textContent = '';

  if (!roll) { document.getElementById('errRoll').textContent = 'Roll number is required'; valid = false; }
  else if (students.some(s => s.roll === roll && s.id !== document.getElementById('editId').value)) {
    document.getElementById('errRoll').textContent = 'Roll number already exists'; valid = false;
  } else document.getElementById('errRoll').textContent = '';

  if (!email) { document.getElementById('errEmail').textContent = 'Email is required'; valid = false; }
  else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) { document.getElementById('errEmail').textContent = 'Invalid email format'; valid = false; }
  else document.getElementById('errEmail').textContent = '';

  if (!course) { document.getElementById('errCourse').textContent = 'Course is required'; valid = false; }
  else document.getElementById('errCourse').textContent = '';

  return valid;
}

function submitStudent() {
  if (!validateForm()) return;

  const editId = document.getElementById('editId').value;
  const photo = document.getElementById('photoPreview').src;
  const studentData = {
    name:    document.getElementById('fName').value.trim(),
    roll:    document.getElementById('fRoll').value.trim(),
    email:   document.getElementById('fEmail').value.trim(),
    phone:   document.getElementById('fPhone').value.trim(),
    course:  document.getElementById('fCourse').value,
    semester:document.getElementById('fSem').value,
    address: document.getElementById('fAddress').value.trim(),
    marks:   Number(document.getElementById('fMarks').value) || 0,
    dob:     document.getElementById('fDob').value,
    photo:   photo && !photo.endsWith('/index.html') ? photo : '',
  };

  if (editId) {
    const idx = students.findIndex(s => s.id === editId);
    if (idx !== -1) {
      students[idx] = { ...students[idx], ...studentData };
      showToast('Student updated successfully!', 'success');
    }
  } else {
    const id = 'std_' + Date.now();
    students.push({ id, ...studentData, createdAt: new Date().toISOString() });
    // Init attendance for new student
    attendanceData[id] = {};
    showToast('Student added successfully!', 'success');
  }

  save();
  clearForm();
  navigate(document.querySelector('[data-page="records"]'));
}

function editStudent(id) {
  const s = students.find(s => s.id === id);
  if (!s) return;
  clearForm();
  document.getElementById('fName').value    = s.name || '';
  document.getElementById('fRoll').value    = s.roll || '';
  document.getElementById('fEmail').value   = s.email || '';
  document.getElementById('fPhone').value   = s.phone || '';
  document.getElementById('fCourse').value  = s.course || '';
  document.getElementById('fSem').value     = s.semester || '';
  document.getElementById('fAddress').value = s.address || '';
  document.getElementById('fMarks').value   = s.marks || '';
  document.getElementById('fDob').value     = s.dob || '';
  document.getElementById('editId').value   = s.id;
  document.getElementById('formTitle').textContent = 'Edit Student';

  if (s.photo) {
    document.getElementById('photoPreview').src = s.photo;
    document.getElementById('photoPreview').classList.remove('hidden');
    document.getElementById('photoPlaceholder').classList.add('hidden');
  }

  navigate(document.querySelector('[data-page="addStudent"]'));
}

function deleteStudent(id) {
  if (!confirm('Delete this student? This cannot be undone.')) return;
  students = students.filter(s => s.id !== id);
  delete attendanceData[id];
  save();
  renderTable(filteredStudents());
  renderDashboard();
  showToast('Student deleted.', 'info');
}

// ============================================================
// RECORDS TABLE
// ============================================================
function renderTable(data) {
  const tbody = document.getElementById('studentsTableBody');
  const empty = document.getElementById('emptyState');

  if (!data || data.length === 0) {
    tbody.innerHTML = '';
    empty.classList.remove('hidden');
    return;
  }
  empty.classList.add('hidden');

  tbody.innerHTML = data.map(s => `
    <tr>
      <td><div class="tbl-avatar">${s.photo ? `<img src="${s.photo}" />` : initials(s.name)}</div></td>
      <td>
        <div class="tbl-name">${s.name}</div>
        <div class="tbl-roll">${s.phone || ''}</div>
      </td>
      <td><code style="font-size:0.82rem;color:var(--accent)">${s.roll}</code></td>
      <td style="font-size:0.85rem">${s.course || '—'}</td>
      <td style="font-size:0.85rem;color:var(--text2)">${s.semester || '—'}</td>
      <td style="font-size:0.82rem;color:var(--text2)">${s.email}</td>
      <td><span class="grade-badge ${gradeClass(s.marks)}">${gradeLabel(s.marks)}</span></td>
      <td>
        <div class="action-btns">
          <button class="btn-view btn-sm" onclick="viewProfile('${s.id}')">View</button>
          <button class="btn-edit btn-sm" onclick="editStudent('${s.id}')">Edit</button>
          <button class="btn-del btn-sm" onclick="deleteStudent('${s.id}')">Del</button>
        </div>
      </td>
    </tr>`).join('');
}

function filteredStudents() {
  const q     = (document.getElementById('searchInput')?.value || '').toLowerCase();
  const course= document.getElementById('filterCourse')?.value || '';
  const sem   = document.getElementById('filterSem')?.value || '';
  const sort  = document.getElementById('sortBy')?.value || '';

  let result = students.filter(s => {
    const matchQ = !q || s.name.toLowerCase().includes(q) || s.roll.toLowerCase().includes(q) || s.email.toLowerCase().includes(q);
    const matchC = !course || s.course === course;
    const matchS = !sem || s.semester === sem;
    return matchQ && matchC && matchS;
  });

  if (sort === 'name')   result.sort((a,b) => a.name.localeCompare(b.name));
  if (sort === 'nameZ')  result.sort((a,b) => b.name.localeCompare(a.name));
  if (sort === 'roll')   result.sort((a,b) => a.roll.localeCompare(b.roll));
  if (sort === 'marks')  result.sort((a,b) => Number(b.marks) - Number(a.marks));
  return result;
}

function filterStudents() {
  renderTable(filteredStudents());
}

// ============================================================
// PROFILE MODAL
// ============================================================
function viewProfile(id) {
  const s = students.find(s => s.id === id);
  if (!s) return;
  const pct = getAttendancePct(id);
  const grade = gradeLabel(s.marks);

  document.getElementById('profileContent').innerHTML = `
    <div class="profile-header">
      <div class="profile-photo">
        ${s.photo ? `<img src="${s.photo}" />` : initials(s.name)}
      </div>
      <div>
        <div class="profile-name">${s.name}</div>
        <div class="profile-roll">${s.roll}</div>
        <div class="profile-course">${s.course || ''} ${s.semester ? '• '+s.semester : ''}</div>
      </div>
    </div>

    <div class="profile-grid">
      <div class="pinfo-item"><div class="pinfo-label">Email</div><div class="pinfo-val" style="font-size:0.82rem">${s.email}</div></div>
      <div class="pinfo-item"><div class="pinfo-label">Phone</div><div class="pinfo-val">${s.phone || '—'}</div></div>
      <div class="pinfo-item"><div class="pinfo-label">Date of Birth</div><div class="pinfo-val">${s.dob ? new Date(s.dob).toLocaleDateString('en-IN') : '—'}</div></div>
      <div class="pinfo-item"><div class="pinfo-label">Address</div><div class="pinfo-val" style="font-size:0.82rem">${s.address || '—'}</div></div>
    </div>

    <div class="dash-card" style="background:var(--bg3);border:none;margin-bottom:14px">
      <div class="card-title">Academic Performance</div>
      <div style="display:flex;gap:20px;flex-wrap:wrap">
        <div>
          <div style="color:var(--text2);font-size:0.75rem;text-transform:uppercase;letter-spacing:0.06em;margin-bottom:4px">Marks</div>
          <div style="font-family:'Syne',sans-serif;font-size:1.8rem;font-weight:800">${s.marks || 0}<span style="font-size:0.9rem;color:var(--text2)">/100</span></div>
          <div class="grade-badge ${gradeClass(s.marks)}" style="margin-top:4px">${grade}</div>
        </div>
        <div style="flex:1">
          <div style="color:var(--text2);font-size:0.75rem;text-transform:uppercase;letter-spacing:0.06em;margin-bottom:8px">Marks Progress</div>
          <div class="perf-bar-wrap">
            <div class="perf-bar-bg"><div class="perf-bar-fill" style="width:${s.marks || 0}%"></div></div>
          </div>
        </div>
      </div>
    </div>

    <div class="dash-card" style="background:var(--bg3);border:none">
      <div class="card-title">Attendance</div>
      <div style="display:flex;align-items:center;gap:16px">
        <div style="font-family:'Syne',sans-serif;font-size:2rem;font-weight:800;color:${pct>=75?'var(--success)':'var(--danger)'}">${pct}%</div>
        <div style="flex:1">
          <div class="perf-bar-bg"><div class="perf-bar-fill" style="width:${pct}%;background:${pct>=75?'linear-gradient(90deg,#34d399,#6ee7f7)':'linear-gradient(90deg,#f87171,#fb923c)'}"></div></div>
          <div style="font-size:0.78rem;color:var(--text2);margin-top:6px">${pct>=75?'✓ Good standing':'⚠ Below 75% minimum'}</div>
        </div>
      </div>
    </div>
  `;

  document.getElementById('profileModal').classList.remove('hidden');
}

function closeProfileModal() {
  document.getElementById('profileModal').classList.add('hidden');
}

function closeModal(event) {
  if (event.target.id === 'profileModal') closeProfileModal();
}

// ============================================================
// ATTENDANCE
// ============================================================
function getAttendancePct(studentId) {
  const records = attendanceData[studentId] || {};
  const entries = Object.values(records);
  if (!entries.length) return 0;
  const present = entries.filter(v => v === 'present').length;
  return Math.round((present / entries.length) * 100);
}

function renderAttendance() {
  // Summary
  let totalPresent = 0, totalAbsent = 0;
  students.forEach(s => {
    const recs = attendanceData[s.id] || {};
    const dayRecord = recs[TODAY];
    if (dayRecord === 'present') totalPresent++;
    else totalAbsent++;
  });
  const total = students.length;
  const pct = total ? Math.round((totalPresent / total) * 100) : 0;

  document.getElementById('attendanceSummary').innerHTML = `
    <div class="att-chip"><strong>${total}</strong><span>Total Students</span></div>
    <div class="att-chip"><strong style="color:var(--success)">${totalPresent}</strong><span>Present Today</span></div>
    <div class="att-chip"><strong style="color:var(--danger)">${totalAbsent}</strong><span>Absent Today</span></div>
    <div class="att-chip"><strong>${pct}%</strong><span>Today's Rate</span></div>
  `;

  // List
  document.getElementById('attendanceList').innerHTML = students.map(s => {
    const status = (attendanceData[s.id] || {})[TODAY] || 'absent';
    const pct = getAttendancePct(s.id);
    return `
    <div class="att-row ${status}" id="attrow_${s.id}">
      <div class="recent-avatar" style="width:36px;height:36px">
        ${s.photo ? `<img src="${s.photo}" style="width:36px;height:36px;border-radius:50%;object-fit:cover" />` : initials(s.name)}
      </div>
      <div class="att-info">
        <div class="att-name">${s.name}</div>
        <div class="att-meta">${s.roll} · ${s.course || '—'}</div>
      </div>
      <div class="att-pct" style="color:${pct>=75?'var(--success)':'var(--danger)'}">${pct}%</div>
      <div class="att-toggle">
        <button class="att-btn ${status==='present'?'active-p':''}" onclick="markAttendance('${s.id}','present')">Present</button>
        <button class="att-btn ${status==='absent'?'active-a':''}" onclick="markAttendance('${s.id}','absent')">Absent</button>
      </div>
    </div>`;
  }).join('') || '<p style="text-align:center;color:var(--text3);padding:40px">No students found.</p>';
}

function markAttendance(studentId, status) {
  if (!attendanceData[studentId]) attendanceData[studentId] = {};
  attendanceData[studentId][TODAY] = status;
  save();
  renderAttendance();
  showToast(`Marked as ${status}`, status === 'present' ? 'success' : 'info');
}

// ============================================================
// ANALYTICS
// ============================================================
function renderAnalytics() {
  renderMarksChart();
  renderTopStudents();
  renderPerfChart();
}

function renderMarksChart() {
  if (marksChart) marksChart.destroy();
  const ctx = document.getElementById('marksChart').getContext('2d');
  const buckets = { '90–100': 0, '75–89': 0, '60–74': 0, '40–59': 0, 'Below 40': 0 };
  students.forEach(s => {
    const m = Number(s.marks) || 0;
    if (m >= 90) buckets['90–100']++;
    else if (m >= 75) buckets['75–89']++;
    else if (m >= 60) buckets['60–74']++;
    else if (m >= 40) buckets['40–59']++;
    else buckets['Below 40']++;
  });

  const textColor = getComputedStyle(document.documentElement).getPropertyValue('--text2').trim();
  const borderColor = getComputedStyle(document.documentElement).getPropertyValue('--border').trim();

  marksChart = new Chart(ctx, {
    type: 'bar',
    data: {
      labels: Object.keys(buckets),
      datasets: [{
        label: 'Students',
        data: Object.values(buckets),
        backgroundColor: ['#34d399','#6ee7f7','#a78bfa','#fb923c','#f87171'],
        borderRadius: 8, borderWidth: 0
      }]
    },
    options: {
      responsive: true, maintainAspectRatio: true,
      plugins: { legend: { display: false } },
      scales: {
        x: { ticks: { color: textColor, font: { family: 'DM Sans', size: 11 } }, grid: { color: borderColor } },
        y: { ticks: { color: textColor, font: { family: 'DM Sans', size: 11 }, stepSize: 1 }, grid: { color: borderColor } }
      }
    }
  });
}

function renderTopStudents() {
  const top5 = [...students].filter(s => s.marks).sort((a,b) => Number(b.marks)-Number(a.marks)).slice(0,5);
  document.getElementById('topStudentsList').innerHTML = top5.length
    ? top5.map((s,i) => `
      <div class="top-item">
        <div class="top-rank">${['🥇','🥈','🥉','④','⑤'][i]}</div>
        <div class="top-info">
          <div class="top-name">${s.name}</div>
          <div class="top-course">${s.course || '—'} · ${s.roll}</div>
        </div>
        <div class="top-marks">${s.marks}</div>
      </div>`).join('')
    : '<p style="color:var(--text3);font-size:0.85rem;text-align:center;padding:20px">No data yet</p>';
}

function renderPerfChart() {
  if (perfChart) perfChart.destroy();
  const ctx = document.getElementById('perfChart').getContext('2d');
  const names = students.slice(0,10).map(s => s.name.split(' ')[0]);
  const marks = students.slice(0,10).map(s => Number(s.marks)||0);

  const textColor = getComputedStyle(document.documentElement).getPropertyValue('--text2').trim();
  const borderColor = getComputedStyle(document.documentElement).getPropertyValue('--border').trim();

  perfChart = new Chart(ctx, {
    type: 'line',
    data: {
      labels: names,
      datasets: [{
        label: 'Marks', data: marks,
        borderColor: '#6ee7f7', backgroundColor: 'rgba(110,231,247,0.1)',
        borderWidth: 2.5, pointBackgroundColor: '#6ee7f7', pointRadius: 5, tension: 0.4, fill: true
      }]
    },
    options: {
      responsive: true, maintainAspectRatio: true,
      plugins: { legend: { labels: { color: textColor, font: { family: 'DM Sans', size: 11 } } } },
      scales: {
        x: { ticks: { color: textColor, font: { family: 'DM Sans', size: 11 } }, grid: { color: borderColor } },
        y: { min: 0, max: 100, ticks: { color: textColor, font: { family: 'DM Sans', size: 11 } }, grid: { color: borderColor } }
      }
    }
  });
}

// ============================================================
// ID CARD
// ============================================================
function renderIDCardSelect() {
  const select = document.getElementById('idCardSelect');
  select.innerHTML = '<option value="">-- Choose a student --</option>' +
    students.map(s => `<option value="${s.id}">${s.name} (${s.roll})</option>`).join('');
}

function renderIDCard() {
  const id = document.getElementById('idCardSelect').value;
  if (!id) { document.getElementById('idCardWrap').classList.add('hidden'); return; }
  const s = students.find(s => s.id === id);
  if (!s) return;

  document.getElementById('idcName').textContent = s.name;
  document.getElementById('idcRoll').textContent = s.roll;
  document.getElementById('idcCourse').textContent = s.course || '—';
  document.getElementById('idcSem').textContent = s.semester || '—';
  document.getElementById('idcEmail').textContent = s.email;

  const photoDiv = document.getElementById('idcPhoto');
  if (s.photo) {
    photoDiv.innerHTML = `<img src="${s.photo}" style="width:100%;height:100%;object-fit:cover" />`;
  } else {
    photoDiv.innerHTML = `<span style="font-family:'Syne',sans-serif;font-weight:800;font-size:1.5rem;color:rgba(110,231,247,0.7)">${initials(s.name)}</span>`;
  }

  document.getElementById('idCardWrap').classList.remove('hidden');
}

function printIDCard() {
  window.print();
}

// ============================================================
// EXPORT CSV
// ============================================================
function exportCSV() {
  const headers = ['Name','Roll','Email','Phone','Course','Semester','Marks','Attendance %','DOB','Address'];
  const rows = students.map(s => [
    `"${s.name}"`, s.roll, s.email, s.phone || '',
    s.course || '', s.semester || '', s.marks || 0,
    getAttendancePct(s.id) + '%', s.dob || '', `"${s.address || ''}"`
  ]);
  const csv = [headers, ...rows].map(r => r.join(',')).join('\n');
  const blob = new Blob([csv], { type: 'text/csv' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url; a.download = 'students_export.csv';
  a.click(); URL.revokeObjectURL(url);
  showToast('CSV exported successfully!', 'success');
}

// ============================================================
// HELPERS
// ============================================================
function initials(name) {
  return (name || '?').split(' ').slice(0,2).map(w => w[0]?.toUpperCase() || '').join('');
}

function gradeLabel(marks) {
  const m = Number(marks) || 0;
  if (m >= 90) return 'A+';
  if (m >= 80) return 'A';
  if (m >= 70) return 'B';
  if (m >= 60) return 'C';
  if (m >= 40) return 'D';
  return 'F';
}

function gradeClass(marks) {
  const g = gradeLabel(marks);
  if (g.startsWith('A')) return 'grade-A';
  if (g === 'B') return 'grade-B';
  if (g === 'C') return 'grade-C';
  return 'grade-F';
}

function showToast(msg, type = 'info') {
  const t = document.getElementById('toast');
  t.textContent = msg;
  t.className = `toast ${type}`;
  t.classList.remove('hidden');
  setTimeout(() => t.classList.add('hidden'), 3000);
}

// ============================================================
// AUTO-INIT (if already logged in flag)
// The user starts at login page. No auto-login for security.
// ============================================================
