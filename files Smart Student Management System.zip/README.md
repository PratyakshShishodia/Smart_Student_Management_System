# ⬡ Smart Student Management System

> A modern, premium-grade Student Management Dashboard built with vanilla HTML, CSS & JavaScript. Internship-ready, portfolio-worthy.

![Smart SMS Preview](./assets/preview.png)

---

## ✨ Features

| Feature | Status |
|---|---|
| Admin Login (admin / admin123) | ✅ |
| Dashboard with live stats & charts | ✅ |
| Add / Edit / Delete Students | ✅ |
| Profile photo upload | ✅ |
| Advanced search & filters | ✅ |
| Attendance Management (daily toggle) | ✅ |
| Performance Analytics (Chart.js) | ✅ |
| Student Profile Modal | ✅ |
| Student ID Card Generator | ✅ |
| Export to CSV | ✅ |
| Dark / Light mode toggle | ✅ |
| Notifications panel | ✅ |
| Fully responsive (mobile-first) | ✅ |
| Persistent localStorage storage | ✅ |

---

## 🚀 Getting Started

```bash
# Just open index.html in any modern browser — no build step needed!
open index.html
```

**Login credentials:**
- Username: `admin`
- Password: `admin123`

---

## 🗂 Project Structure

```
smart-sms/
├── index.html      # Main app shell + all pages
├── style.css       # Full design system + responsive styles
├── script.js       # All app logic, state, localStorage
├── assets/         # Images, icons
└── README.md
```

---

## 🛠 Technologies

- **HTML5** — Semantic structure, single-page architecture
- **CSS3** — Custom properties, Grid, Flexbox, animations, dark/light themes
- **JavaScript (ES6+)** — Modules, localStorage, File API, CSV export
- **Chart.js** — Doughnut, bar, line charts
- **Google Fonts** — Syne + DM Sans

---

## 📄 Pages

1. **Login Page** — Secure admin authentication
2. **Dashboard** — KPI cards, course distribution chart, 7-day attendance chart, recent students
3. **Add Student** — Photo upload, full form with validation
4. **Records** — Searchable, filterable, sortable table with inline actions
5. **Attendance** — Daily present/absent toggle per student with percentage tracking
6. **Analytics** — Marks distribution, top 5 leaderboard, performance line chart
7. **ID Card Generator** — Printable student identity card

---

## 📝 Resume Description

> "Developed a full-featured, responsive Student Management System with admin authentication, student record CRUD operations, daily attendance tracking, performance analytics dashboard with Chart.js visualizations, CSV export, student ID card generator, and dark/light mode toggle using vanilla HTML, CSS, and JavaScript with localStorage persistence."

---

## 📸 Design Highlights

- **Dark-first** premium dashboard aesthetic
- **Syne** display font for headings — strong editorial personality
- **Glassmorphism-inspired** cards with subtle borders and shadows
- Animated stat cards, smooth page transitions, interactive hover states
- Responsive from 320px mobile to 4K desktop

---

## 🤝 Contributing

Pull requests welcome! For major changes, open an issue first.

---

## 📜 License

MIT © 2024 Smart SMS
